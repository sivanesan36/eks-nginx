# eks-nginx
Scripts to go with my tutorial ["How to deploy Nginx on EKS Kubernetes"](https://youtu.be/c4WcYjama6U)

Other helpful links:
https://eksworkshop.com/beginner/130_exposing-service/connecting/
https://kubernetes.io/docs/tasks/access-application-cluster/create-external-load-balancer/#using-kubectl
https://kubernetes.io/docs/tutorials/hello-minikube/