#!/bin/bash
kubectl get svc my-nginx-service

minikube service my-nginx-service